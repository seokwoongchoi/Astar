#pragma once
#include "ISubsystem.h"

class Mouse final : public ISubsystem
{
public:
	Mouse(class Context* context);
	~Mouse();

	const D3DXVECTOR3& GetPosition() const { return position; }
	const D3DXVECTOR3& GetMoveValue() const { return wheelMoveValue; }

	LRESULT InputProc(IN const uint& message, IN const WPARAM& wParam, IN const LPARAM& lParam);

	void Initialize() override {}
	void Update() override;

	const bool Down(IN const DWORD& button) const { return buttonMap[button] == static_cast<uint>(ButtonStatus::BUTTON_INPUT_STATUS_DOWN); }
	const bool Up(IN const DWORD& button) const { return buttonMap[button] == static_cast<uint>(ButtonStatus::BUTTON_INPUT_STATUS_UP); }
	const bool Press(IN const DWORD& button) const { return buttonMap[button] == static_cast<uint>(ButtonStatus::BUTTON_INPUT_STATUS_PRESS); }

private:
	enum class MouseRotationState
	{
		MOUSE_ROTATION_NONE = 0,
		MOUSE_ROTATION_LEFT,
		MOUSE_ROTATION_RIGHT
	};

	enum class ButtonStatus
	{
		BUTTON_INPUT_STATUS_NONE = 0,
		BUTTON_INPUT_STATUS_DOWN,
		BUTTON_INPUT_STATUS_UP,
		BUTTON_INPUT_STATUS_PRESS,
		BUTTON_INPUT_STATUS_DBLCLK
	};

private:
	byte buttonStatus[MAX_INPUT_MOUSE];
	byte buttonOldStatus[MAX_INPUT_MOUSE];
	byte buttonMap[MAX_INPUT_MOUSE];
	DWORD timeDblClk;
	DWORD startDblClk[MAX_INPUT_MOUSE];
	int buttonCount[MAX_INPUT_MOUSE];

	D3DXVECTOR3 position; //���콺 ��ġ
	D3DXVECTOR3 wheelStatus;
	D3DXVECTOR3 wheelOldStatus;
	D3DXVECTOR3 wheelMoveValue;
};

