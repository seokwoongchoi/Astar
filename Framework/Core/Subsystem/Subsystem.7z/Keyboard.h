#pragma once
#include "ISubsystem.h"

class Keyboard final : public ISubsystem
{
public:
	Keyboard(class Context* context);
	~Keyboard();

	void Initialize() override {}
	void Update() override;

	const bool Down(IN const DWORD& key) const { return keyMap[key] == static_cast<uint>(KeyStatus::KEY_INPUT_STATUS_DOWN); }
	const bool Up(IN const DWORD& key) const { return keyMap[key] == static_cast<uint>(KeyStatus::KEY_INPUT_STATUS_UP); }
	const bool Press(IN const DWORD& key) const { return keyMap[key] == static_cast<uint>(KeyStatus::KEY_INPUT_STATUS_PRESS); }

private:
	enum class KeyStatus
	{
		KEY_INPUT_STATUS_NONE = 0,
		KEY_INPUT_STATUS_DOWN,
		KEY_INPUT_STATUS_UP,
		KEY_INPUT_STATUS_PRESS,
	};

private:
	byte keyState[MAX_INPUT_KEY];
	byte keyOldState[MAX_INPUT_KEY];
	byte keyMap[MAX_INPUT_KEY];
};